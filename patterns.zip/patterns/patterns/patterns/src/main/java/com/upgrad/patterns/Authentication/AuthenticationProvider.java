package com.upgrad.patterns.Authentication;

public abstract class AuthenticationProvider {
    public abstract boolean Authenticate();
}
